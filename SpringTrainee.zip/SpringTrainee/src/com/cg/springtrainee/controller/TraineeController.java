package com.cg.springtrainee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.springtrainee.dto.Trainee;
import com.cg.springtrainee.service.ITraineeService;



@Controller
public class TraineeController {
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="/addtrainee")
	public String getTrainee(@ModelAttribute("my")Trainee trainee,Map<String,Object> model ){
    	List<String> myList = new ArrayList<>();
    	myList.add("JAVA");
    	myList.add("PYTHON");
    	myList.add("DOTNET");
    	model.put("cato", myList);
		return "AddTrainee";
	}
	 @RequestMapping(value="adddata",method=RequestMethod.POST)
	    public String addMobileData( @Valid@ModelAttribute("my") Trainee trainee,  BindingResult result,Map<String,Object> model ){
	    	if(result.hasErrors()){
	    		List<String> myList = new ArrayList<>();
	        	myList.add("JAVA");
	        	myList.add("PYTHON");
	        	myList.add("DOTNET");
	        	model.put("cato", myList);
	    		return "AddTrainee";
	    	}
	    	else{
	    		traineeservice.addTrainee(trainee);
	    		return "success";
	    	}	}
}
