package com.cg.springtrainee.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trainee")
public class Trainee {
	@Id
	@Column(name="trainee_id")
	int TraineeId;

	@Column(name="trainee_name")
	String TraineeName;

	@Column(name="trainee_domain")
	String TraineeDomain;

	@Column(name="trainee_location")
	String TraineeLocation;
	
	
	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Trainee(int traineeId, String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		TraineeId = traineeId;
		TraineeName = traineeName;
		TraineeDomain = traineeDomain;
		TraineeLocation = traineeLocation;
	}


	public int getTraineeId() {
		return TraineeId;
	}


	public void setTraineeId(int traineeId) {
		TraineeId = traineeId;
	}


	public String getTraineeName() {
		return TraineeName;
	}


	public void setTraineeName(String traineeName) {
		TraineeName = traineeName;
	}


	public String getTraineeDomain() {
		return TraineeDomain;
	}


	public void setTraineeDomain(String traineeDomain) {
		TraineeDomain = traineeDomain;
	}


	public String getTraineeLocation() {
		return TraineeLocation;
	}


	public void setTraineeLocation(String traineeLocation) {
		TraineeLocation = traineeLocation;
	}


	@Override
	public String toString() {
		return "Trainee [TraineeId=" + TraineeId + ", TraineeName="
				+ TraineeName + ", TraineeDomain=" + TraineeDomain
				+ ", TraineeLocation=" + TraineeLocation + "]";
	}
	
	
	

}
