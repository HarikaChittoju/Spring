package com.cg.springtrainee.dao;

import java.util.List;

import com.cg.springtrainee.dto.Trainee;

public interface ITraineeDao {
	public void addTrainee(Trainee trainee);
	public void deleteTrainee(int traineeId);
	public void updateTrainee(Integer traineeId, String traineeName, String traineeDomain,String traineeLocation);
	public void retrieveTrainee(Integer traineeId);
	public List<Trainee>retrieveAllTrainee();

}
