package com.cg.springtrainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.cg.springtrainee.dto.Trainee;
import com.cg.springtrainee.service.ITraineeService;
@Repository("traineedao")

public class TraineeDaoImpl implements ITraineeService{

	@Autowired
	ITraineeService traineeservice;

	@PersistenceContext
	EntityManager em;
	@Override
	
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		em.persist(trainee);
		em.flush();
	}

	@Override
	public void deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateTrainee(Integer traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void retrieveTrainee(Integer traineeId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Trainee> retrieveAllTrainee() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
