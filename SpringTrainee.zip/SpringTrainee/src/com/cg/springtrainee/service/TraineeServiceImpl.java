package com.cg.springtrainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springtrainee.dao.ITraineeDao;
import com.cg.springtrainee.dto.Trainee;
@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService{

	@Autowired
	ITraineeDao traineedao;
	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		traineedao.addTrainee(trainee);
		
	}

	@Override
	public void deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateTrainee(Integer traineeId, String traineeName,
			String traineeDomain, String traineeLocation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void retrieveTrainee(Integer traineeId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Trainee> retrieveAllTrainee() {
		// TODO Auto-generated method stub
		return null;
	}
	

}

	


